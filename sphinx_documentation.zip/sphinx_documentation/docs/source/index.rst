.. Kanchi-Lug-RESTApi documentation master file, created by
   sphinx-quickstart on Sun Jul 11 13:48:15 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Kanchi-Lug-RESTApi's documentation!
==============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:


API main
=========
.. automodule:: app
   :members:


Authorization
=============
.. automodule:: common.auth
   :members:

Error Handling
==============
.. automodule:: common.errors
   :members:

Resources Handling
==================
.. automodule:: resources.members
   :members:



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
